from flask import Flask, render_template, request, flash
import os
import sqlite3

app = Flask(__name__)
app.secret_key = os.urandom(24)

@app.route("/")
def index():
    return render_template("registration.html")


@app.route('/signup')
def signup():
    return render_template('signup.html')


@app.route('/reg', methods=["POST"])
def reg():
    name = request.form['first_name']
    last_name = request.form['last_name']
    email = request.form['email']
    password = request.form['password']
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users
                 (id INTEGER PRIMARY KEY, name TEXT NOT NULL,last_name TEXT NOT NUll, email TEXT UNIQUE NOT NULL, password TEXT NOT NULL)''')

    c.execute("SELECT * FROM users WHERE email = ?", (email,))
    existing_user = c.fetchone()

    if existing_user:
        # Пользователь с таким email уже существует
        flash('Пользователь с таким email уже существует', 'danger')
        return render_template('signup.html')
    c.execute('''CREATE TABLE IF NOT EXISTS users
             (id INTEGER PRIMARY KEY, name TEXT NOT NULL,last_name TEXT NOT NUll, email TEXT UNIQUE NOT NULL, password TEXT NOT NULL)''')
    c.execute("INSERT INTO users (name, last_name, email, password) VALUES (?, ?, ?, ?)", (name, last_name, email, password))
    conn.commit()
    conn.close()
    return render_template('login.html')


@app.route('/login')
def login():
    return render_template('login.html')


@app.route('/enter', methods=['POST'])
def enter():
    email = request.form['email']
    password = request.form['password']
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE email = ?", (email,))
    user = c.fetchone()
    if user and user[4] == password:
        return render_template('main.html')
    else:
        flash('Указан не верный логин или пароль', 'danger')
        render_template('login.html')


if __name__ == "__main__":
    key_path = os.path.join('server.key')
    cert_path = os.path.join('server.crt')
    app.run(debug=True, ssl_context=(cert_path, key_path))