from dotenv import load_dotenv
import os

load_dotenv()


class Secrets:
    token: str = os.environ.get("TOKEN")
