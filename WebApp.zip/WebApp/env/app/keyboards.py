from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from aiogram.types.web_app_info import WebAppInfo
import os

main_keyboard = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text='Регистрация',
                                                                            web_app=WebAppInfo(url='https://127.0.0.1:5000')),
                                                       InlineKeyboardButton(text='Обменный курс валют Binance',
                                                                            web_app=WebAppInfo(url='https://Binance.com'))]])
