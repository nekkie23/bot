import asyncio


from aiogram import Bot, Dispatcher
from aiogram.filters import CommandStart
from aiogram.types import Message
from app.keyboards import main_keyboard
from dotenv import load_dotenv
from app.settings import Secrets


bot = Bot(Secrets.token)
dp = Dispatcher()


async def main():
    await dp.start_polling(bot)


@dp.message(CommandStart())
async def start(message: Message):
    await message.answer('Привет. Меня зовут Рамиль. Я твой помошник по арбитражу.', reply_markup=main_keyboard)


if __name__ == '__main__':
    asyncio.run(main())

